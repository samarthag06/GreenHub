import express from 'express';
import User from '../models/User.js';
import auth from '../middleware/auth.js';

const router = express.Router();

// Get all posts
router.get('/posts', async (req, res) => {
  try {
    const posts = await User.aggregate([
      { $unwind: '$posts' },
      { $sort: { 'posts.createdAt': -1 } },
      { $limit: 50 },
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'user'
        }
      },
      { $unwind: '$user' },
      {
        $project: {
          _id: '$posts._id',
          content: '$posts.content',
          image: '$posts.image',
          productId: '$posts.productId',
          greenCredits: '$posts.greenCredits',
          createdAt: '$posts.createdAt',
          user: {
            _id: '$user._id',
            name: '$user.name'
          }
        }
      }
    ]);

    res.json(posts);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Create post
router.post('/posts', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const post = {
      content: req.body.content,
      image: req.body.image,
      productId: req.body.productId,
      greenCredits: req.body.productId ? 5 : 1, // More credits for product-related posts
      createdAt: new Date()
    };

    user.posts.push(post);
    user.greenCredits += post.greenCredits;
    await user.save();

    res.status(201).json(post);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;