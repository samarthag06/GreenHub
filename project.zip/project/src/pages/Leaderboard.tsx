import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { getLeaderboard } from '../api/users';
import { Trophy, Award } from 'lucide-react';

function Leaderboard() {
  const { data: leaders, isLoading } = useQuery({
    queryKey: ['leaderboard'],
    queryFn: getLeaderboard,
  });

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Green Leaders</h1>
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="space-y-4">
          {leaders?.map((user: any, index: number) => (
            <div
              key={user._id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-4">
                {index < 3 ? (
                  <Trophy className={`h-6 w-6 ${
                    index === 0 ? 'text-yellow-500' :
                    index === 1 ? 'text-gray-400' :
                    'text-orange-500'
                  }`} />
                ) : (
                  <span className="w-6 text-center font-semibold">{index + 1}</span>
                )}
                <div>
                  <p className="font-semibold">{user.name}</p>
                  <p className="text-sm text-gray-500">Total Orders: {user.purchaseHistory.length}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Award className="h-5 w-5 text-green-600" />
                <span className="font-bold">{user.greenCredits}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Leaderboard;