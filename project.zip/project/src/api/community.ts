import api from './axios';

export const getPosts = async () => {
  const { data } = await api.get('/community/posts');
  return data;
};

export const createPost = async (postData: {
  content: string;
  productId?: string;
  image?: string;
}) => {
  const { data } = await api.post('/community/posts', postData);
  return data;
};