import api from './axios';

export const getProducts = async () => {
  const { data } = await api.get('/products');
  return data;
};

export const getProductById = async (id: string) => {
  const { data } = await api.get(`/products/${id}`);
  return data;
};

export const createProduct = async (productData: FormData) => {
  const { data } = await api.post('/products', productData);
  return data;
};