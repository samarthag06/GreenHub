import api from './axios';

export const getUserProfile = async () => {
  const { data } = await api.get('/users/profile');
  return data;
};

export const getLeaderboard = async () => {
  const { data } = await api.get('/users/leaderboard');
  return data;
};

export const updateProfile = async (userData: {
  name?: string;
  email?: string;
  password?: string;
}) => {
  const { data } = await api.put('/users/profile', userData);
  return data;
};